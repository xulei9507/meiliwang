$(function(){
	$.ajax({
		type:"get",
		url:"huodong.json",
		async:true,
		success:function(data){
			var address = data.datas;
			creathuodongthings1(address,".huodong_things");
		}
	});
	var creathuodongthings1 = function(address,dom){
		for(var j = 0;j<address.length;j++){
			var divhuodongthings1 = $(
				'<div class="huodong_things1">' +
					'<div class="huodong_things2">' +
                        '<div class="huodong_img">' +
                        	'<a href="#">' +
                               '<img src="' + address[j].imgSrc + '" width="170" height="170" alt="">' +
                               '<div class="huodong_save_txt">' + address[j].saveone + '</div>' +
                               '<img class="huodong_save_img" src="images/tag2.png">' +
                        	'</a>' +
                        '</div>' +
                        '<div class="huodong_product_name">' +
                              '<a href="#">' + address[j].productname + '</a>' +
                        '</div>' +
                        '<div class="huodong_fenlan"></div>' +
                        '<div class="huodong_price">' +
                        	'<p class="huodong_price1"><b>USD <s>' + address[j].priceone + '</s></b></p>' +
                        	'<p class="huodong_price1">' + address[j].pricetwo + '</p>' +
                        	'<p class="huodong_price_usd"><b>' + address[j].pricethree + '</b></p>' +
                        	'<p class="huodong_price_save">' + address[j].savetwo + '</p>' +
                        '</div>' +
					'</div>' +
				'</div>'
			)			
			$(dom).append(divhuodongthings1);
		}
	}
	
})
