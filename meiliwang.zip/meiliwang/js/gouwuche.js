$(function(){

	
	//添加到购物车
		//读取本地数据
	var productsStr = localStorage["products"];
	if(!productsStr){
		localStorage["products"] = '[]';
	}
	productsStr = localStorage["products"];
	//转换成数组对象
	var productsObj = JSON.parse(productsStr);
	//productsObj []
	if(productsObj.length==0){
		//alert(1)
		$(".mybask_produce span").show();
		$(".fuyunfangshi_bt").css('visibility','hidden');
		$(".fuyunfangshi").css('visibility','hidden');
		$(".tuiguangfanghsi").hide();
		$(".fukuaniliao_bt").hide();
		$(".fukuanfangfa").hide();
		$(".goumai").hide();
		$(".shopping_cart_notice").hide();
		
	}else{
//		alert(1)
		$(".mybask_produce span").hide();
		$(".fuyunfangshi_bt").css('visibility','visible');
		$(".fuyunfangshi").css('visibility','visible');
		$(".tuiguangfanghsi").show();
		$(".fukuaniliao_bt").show();
		$(".fukuanfangfa").show();
		$(".goumai").show();
		$(".shopping_cart_notice").show();
		for(var i = 0;i<productsObj.length;i++){
			var currentObj = productsObj[i];
			//'+currentObj.pImgSrc+'
			$(
				'<tr bgcolor="#FFFFFF" class="mybask_things" id="mybask_things1">' +
                    '<td align="center" width="100" valign="top"><a href="#"><img src="'+currentObj.pImgSrc+'" alt=""></a></td>' +                                    
                    '<td width="140">'  +
                    	'<img src="'+currentObj.pIconSrc+'" alt="">' +
                        '<a href="#">Cle de Peau&nbsp;</a><br>' +
                        '<a href="#">'+currentObj.pName+'</a><br>' +
                        '<br> 容量: '+currentObj.pRongliang+'<br>'+currentObj.pHuohao+'' +                                                  
                    '</td>' +
                    '<td class="content_txt" align="center" width="100">' +
                        '<b class="things_danjia">'+currentObj.prcie1+'</b><br><br>' +
                        '<font><s>'+currentObj.prcie2+'</s></font><br>' +
                        '<font class="things_produce_price3">'+currentObj.prcie3+'</font><br>' +
                    '</td>' +
                    '<td align="center" width="40">' +
                        '<select class="gouwuche_shuliang">' +
                          '<option value="1" selected="selected">1</option>' +
                          '<option value="2">2</option>' +
                          '<option value="3">3</option>' +
                          '<option value="4">4</option>' +
                          '<option value="5">5</option>' +
                        '</select>' +
                    '</td>' +
                    '<td align="center" width="106" class="gouwuche_xiaoji">'+currentObj.prcie1*currentObj.pNumber+'.00</td>' +
                    '<td align="center" height="30" width="90"><a href="#"><img src="images/remove_01.gif" height="21" width="36" border="0" alt="Remove" class="mybask_delete" id="mybask_delete1"></a></td>' +
                '</tr>'
	        ).appendTo($(".gouwucart"))
	        zongjihanshu();
		}
	}
//		数量
	//动态小计
	$(".gouwuche_shuliang").blur(function(){
		var shuliang=$(".gouwuche_shuliang").val();
	//	console.log(shuliang)
		var danjia =$(".things_danjia").text();
//		console.log(danjia)
		var xiaoji= shuliang*danjia;
		$(".gouwuche_xiaoji").html(xiaoji+'.00');
		var zongji=Number($("#gouwuche_xiaoji").text())+Number($(".gouwuche_xiaoji").text());
		$(".gouwuche_add_money b").html(zongji+'.00');
	})
	//固定小计
	$("#gouwuche_shuliang").blur(function(){
		var shuliang=$("#gouwuche_shuliang").val();
	//	console.log(shuliang)
		var danjia =$("#danjia").text();
//		console.log(danjia)
		var xiaoji= shuliang*danjia;
		$("#gouwuche_xiaoji").html(xiaoji+'.00');
		var zongji=Number($("#gouwuche_xiaoji").text())+Number($(".gouwuche_xiaoji").text());
		$(".gouwuche_add_money b").html(zongji+'.00');
	})
//		总计
    function zongjihanshu(){
    	var zongji=Number($("#gouwuche_xiaoji").text())+Number($(".gouwuche_xiaoji").text());
		$(".gouwuche_add_money b").html(zongji+'.00');
    }
	


//		删除
	//鼠标滑过删除改变图片
	//动态添加购物车删除按钮
	$("#mybask_delete1").mouseover(function(){
    	$('#mybask_delete1').attr('src','images/remove_02.gif');
    }).mouseout(function(){
    	$('#mybask_delete1').attr('src','images/remove_01.gif');
    })	
    zongjihanshu();
    //固定购物车删除按钮
    $("#mybask_delete2").mouseover(function(){
    	$('#mybask_delete2').attr('src','images/remove_02.gif');
    }).mouseout(function(){
    	$('#mybask_delete2').attr('src','images/remove_01.gif');
    })	
    zongjihanshu();
	//点击删除删除整行数据
	//动态添加购物车删除按钮
	$("#mybask_delete1").click(function(){
		$("#mybask_things1").remove();
		localStorage.removeItem("products");
		window.location.reload();
		
	})
	zongjihanshu();
	//固定购物车删除按钮
	$("#mybask_delete2").click(function(){
		$("#mybask_things2").remove();
		localStorage.removeItem("products");
		$(".mybask_produce span").hide();
	})
	zongjihanshu();
//		摸态框金额
	$(".jiezhang").click(function(){
		if($(".payway").val()==0){
			$(".fukuanfangfa b").css("display","inline-block");
		}else{
			$(".goumai_box,.goumai_queren").css("display","block");
		}
	})
	$(".goumai_queren button").click(function(){
		$(".goumai_box,.goumai_queren").css("display","none");
	})
	
	$(".jiezhang").mouseover(function(){
    	$('.jiezhang').attr('src','images/btn_sc_checkout_02.gif');
    }).mouseout(function(){
    	$('.jiezhang').attr('src','images/btn_sc_checkout_01.gif');
    })
	
	
})