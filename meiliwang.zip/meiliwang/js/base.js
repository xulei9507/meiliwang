//------------------公共js-------------------------------
$(function(){
//--------------------------头部--------------------------
	//鼠标滑过中国出现隐藏菜单
	$(".china").hover(function(){//hover鼠标移入移开
		$(".menu1").slideDown(1000).show();
	},function(){
		$(".menu1").css('display','block');
		$(".menu1").delay(500).slideUp(800);//delay延迟
	})
	//鼠标滑过简体出现隐藏菜单
	$(".language").hover(function(){
		$(".menu2").slideDown(300).show();
	},function(){
		$(".menu2").css('display','block');
		$(".menu2").delay(700).slideUp(500);
	})
//--------------------------登录--------------------------
	var userName = localStorage["name"];
	var islogin = localStorage["isLogin"];
	if(islogin){
		if(islogin=="true"){
			$(".top_login_txt").show();
			$(".top_login_txt_name").text(userName);
			$(".top_mybag").show();
			$(".top_bg").show();
			$(".top_logout").show();
			$(".top_login").hide();
			$(".top_register").hide();
		}
	}
	$(".top_logout").click(function(){
		localStorage["isLogin"] = "false";
		$(".top_login_txt").hide();
		$(".top_mybag").hide();
		$(".top_bg").hide();
		$(".top_logout").hide();
		$(".top_login").show();
		$(".top_register").show();
		window.location.href = "shouye.html";
	})


//--------------------------背景--------------------------
	//促销信息 由小变大
	$(".promotion").ready(function(){
		$(".promotion").delay(500).animate({
			'font-size':'18px'
		},1)
		//$(".promotion").css('font-size','12px').delay(1000).css('font-size','18px')
	})
	//导航
	/*
	$(".nav1").mouseover(function(){
    	$('.nav1').attr('src','images/1_skincare_o.png');
    }).mouseout(function(){
    	$('.nav1').attr('src','images/1_skincare.png');
    })
	*/
	
	//搜索
		//搜索框
		//onblur="if(this.value=='')this.value=' 输入关键词 或 货品编号 ';" onfocus="if(this.value==' 输入关键词 或 货品编号 ')this.value='';"
		/*表单元素选择器：  
			$(":input")选择所有的表单输入元素，包括input, textarea, select 和 button  
			$(":text")选择所有的text input元素  */
    $(".search1").focus(function(){//focus获取焦点    //做个逻辑判断，如果值为默认值，就将文本框中的内容清空。
        $(this).addClass("focus");//当获取焦点时，就添加样式focus
        if($(this).val() ==this.defaultValue){//defaultValue 设置或返回文本域的默认值。 
            $(this).val("");           
        } 
    }).blur(function(){//blur失去焦点	//失去焦点，如果文本框中为空，也就是没有输入内容，就将值还设为默认值。
        $(this).removeClass("focus");
        if ($(this).val() == '') {
            $(this).val(this.defaultValue);
        }
    });
    	//搜索按钮
    	//onmouseover="move_in('search_01','search_button_02.gif');" onmouseout="move_out('search_01','search_button_01.gif');
		/*
		 function move_in(img_name,img_src)
		{
			document[img_name].src = "../images/" + img_src;
		}
		
		function move_out(img_name,img_src)
		{
			document[img_name].src = "../images/" + img_src;
		}
		 * */
    	//jQuery修改img的src的方法:$("#img_id").attr("src","new_src");此语句的功能是:修改id为img_id的src属性为新的src属性。
    $(".search3").mouseover(function(){
    	$('.search3_1').attr('src','images/search_button_02.gif');
    }).mouseout(function(){
    	$('.search3_1').attr('src','images/search_button_01.gif');
    })
   /*$(".search1").bind("propertychange",function(){  
        var txtChange = $(".search1").val();  
        $("search1").html(txtChange);  
    }); */
   
   //------------------------页面底部邮箱 --------------------------
   //页面底部邮箱 鼠标滑过递交按钮变换颜色
    $(".bottom2-btn img").mouseover(function(){
    	$('.bottom2-btn img').attr('src','images/login_button_02.gif');
    }).mouseout(function(){
    	$('.bottom2-btn img').attr('src','images/login_button_01.gif');
    })
   //页面底部邮箱验证
    $(".nemail").focus(function(){//focus获取焦点    //做个逻辑判断，如果值为默认值，就将文本框中的内容清空。
        $(this).addClass("focus");//当获取焦点时，就添加样式focus
        if($(this).val() ==this.defaultValue){//defaultValue 设置或返回文本域的默认值。 
            $(this).val("");           
        } 
    }).blur(function(){//blur失去焦点	//失去焦点，如果文本框中为空，也就是没有输入内容，就将值还设为默认值。
        $(this).removeClass("focus");
        if ($(this).val() == '') {
            $(this).val(this.defaultValue);
        }
    });
    	//点击递交按钮后 判断邮箱格式是否正确
   $("#bottom2_btn").click(function(){
    	var nemail=$("#nemail").val();
  		if(nemail=='  电邮地址  '){
  			//$("#err_email").css('display','block');
  			$("#err_email").show();
  			$(".nemail_err2").hide();
  		}else{
	  		if(!nemail.match(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/)){
	  			$("#err_email").show();
	  			$(".nemail_err2").show();
	   			$(".nemail_err1").hide();
	  		}else{
	  			$("#err_email").hide();
	  		}
  		}
   })
   
   
   
   
   
   //可视页面底部菜单动态时间"2016.07.18 10:10:38 HKT"
		//显示当前时间的工具
function currenttime(){
	var date=new Date();
	var year = date.getFullYear();//年
	var month = date.getMonth() + 1;//月
	if(month<10){
		month = '0'+month;
	}
	var day = date.getDate();//日
	if(day<10){
		day = '0'+day;
	}
	var hours = date.getHours();//时
	if(hours<10){
		hours = '0'+hours;
	}
	var minutes = date.getMinutes();//分
	if(minutes<10){
		minutes = '0'+minutes;
	}
	var seconds = date.getSeconds();//秒
	if(seconds<10){
		seconds = '0'+seconds;
	}
	var str =  year + "." +  month + "." + day + " " + hours + ":" + minutes + ":" + seconds + " HKT";
	return str; 
}
$("#clock").html(currenttime);
setInterval(function(){$("#clock").html(currenttime)},1000);

//$(".menu_cart").click(function(){
//	window.open('gouwuche.html','_self')
//	
//})




})




//logo
	//购物车文字上下滚动
function scroll_news(){
    //$(function(){
    	//fadeOut透明度的变化的淡出效果
    	//slideUp向上滑动 slideUp([speed速度,[easing]效果,[fn]函数])
    	$('.bag3 li').eq(0).slideUp('slow',function(){
    		//   alert($(this).clone().html());
    		//clone克隆:不用克隆的话，remove()就没了。
    		//克隆这个li节点到
    		//appendTo（）把所有匹配的元素追加到另一个指定的元素元素集合中。
    		//fadeIn([speed],[easing],[fn])淡入效果
    		$(this).clone().appendTo($(this).parent()).fadeIn(5000);
    		$(this).remove();
    	});
    //});
}
setInterval('scroll_news()',3000);


 