$(function(){
//会员登录
	//登录时点击电子邮箱的input会删除默认的value，不输入任何值失去焦点会返回原来的value
	$(".email_txt").focus(function(){//focus获取焦点    //做个逻辑判断，如果值为默认值，就将文本框中的内容清空。
        $(this).addClass("focus");//当获取焦点时，就添加样式focus
        if($(this).val() ==this.defaultValue){//defaultValue 设置或返回文本域的默认值。 
            $(this).val("");           
        } 
    }).blur(function(){//blur失去焦点	//失去焦点，如果文本框中为空，也就是没有输入内容，就将值还设为默认值。
        $(this).removeClass("focus");
        if ($(this).val() == '') {
            $(this).val(this.defaultValue);
        }
    });
	//点击现在登录按钮后 判断邮箱格式是否正确
    $("#login_now").click(function(){
    	var email_txt=$("#email_txt").val();
    	var password_txtbox=$("#password_txtbox").val();
  		if(!email_txt.match(/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/)){
   			$(".denglu_error").css('display','block');
  		}else{
  			$(".denglu_error").css('display','none');
  			
  			var userName = localStorage["name"];
  			var useremail=localStorage["email"];
			var pwd = localStorage["pwd"];
			var islogin = localStorage["isLogin"];
			var useremail2 = $("#email_txt")
			var pwd2 = $("#password_txtbox")
			var v = useremail2.val();
			var p = pwd2.val();
			console.log(v==useremail)
			if(v==useremail&&p==pwd){
				localStorage["isLogin"] = "true";
				alert("登录成功");
				window.location.href = "shouye.html";
			}
  			
  		}
    })
    
    //登录用户验证
    
    
    
    
    
//新会员注册	
//	$(".submit a").click(function(){
//		//alert(1);
//		var flag = true; 
////		if (flag) { 
////			$("#uiform").form("destroy"); 
////			alert('验证通过！'); 
////		} 
//		
//		
//		//****个人资料 姓名 称呼****
//		
//			var nametitle = $(".nametitle_box").val();
//			var name_txt= $(".name_txt").val();
////			if('nametitle=="--"'&&'name_txt==0'){
////				//alert(1);
////				$("#errMess1s").css("visibility","visible");
////				$("#zhuce_errMess").show();
////				$("#zhuce_errMess li").hide();
////				$("#errMess1").show();
////				
////			}
//			if('nametitle!="--"'&&'name_txt!=0'){
//				$("#errMess1s").css("visibility","hidden");
//				$("#zhuce_errMess").show();
//				$("#errMess1").hide();
//			}
//
//		
//		
//		//****个人资料  所在地****
////			var country_box = $(".country_box").val();
////			if(country_box=="--"){
////				//alert(1);
////				$("#errMess2s").css("visibility","visible");
////				$("#zhuce_errMess").show();
////				$("#zhuce_errMess li").hide();
////				$("#errMess2").show();
////				
////			}
////			if(country_box!="--"){
////				$("#errMess2s").css("visibility","hidden");
////				//$("#zhuce_errMess")..hide();
////				$("#errMess2").hide();
////				
////			}
//
//		
//	})
	
	
	//****我喜爱的护肤品牌  文本框 ****
	$(".pinpai_txt").focus(function(){//focus获取焦点    //做个逻辑判断，如果值为默认值，就将文本框中的内容清空。
        $(this).addClass("focus");//当获取焦点时，就添加样式focus
        if($(this).val() ==this.defaultValue){//defaultValue 设置或返回文本域的默认值。 
            $(this).val("");           
        } 
    }).blur(function(){//blur失去焦点	//失去焦点，如果文本框中为空，也就是没有输入内容，就将值还设为默认值。
        $(this).removeClass("focus");
        if ($(this).val() == '') {
            $(this).val(this.defaultValue);
        }
    });
	//****图像核证   输入框****
	$(".yanzheng_txt").focus(function(){//focus获取焦点    //做个逻辑判断，如果值为默认值，就将文本框中的内容清空。
        $(this).addClass("focus");//当获取焦点时，就添加样式focus
        if($(this).val() ==this.defaultValue){//defaultValue 设置或返回文本域的默认值。 
            $(this).val("");           
        } 
    }).blur(function(){//blur失去焦点	//失去焦点，如果文本框中为空，也就是没有输入内容，就将值还设为默认值。
        $(this).removeClass("focus");
        if ($(this).val() == '') {
            $(this).val(this.defaultValue);
        }
    });
    $("#btn_yanzheng").click(function(){
    	var zhengshu=parseInt(2*Math.random()+1);
    	$(".yanzheng_image img").attr('src','images/yanzhengma'+ zhengshu +'.png');
    	
    })
    //递交按钮滑过图片变色
    $(".submit a img").mouseover(function(){
    	$('.submit a img').attr('src','images/submit_02.gif');
    }).mouseout(function(){
    	$('.submit a img').attr('src','images/submit_01.gif');
    })
    
    
    
    
    
    
    
    
    
    
    
    
    
    
})
