$(function(){
//	$.ajax({
//		type:"get",
//		url:"shangpinliebiao.json",
//		async:true,
//		success:function(data){
//			var address = data.datas;
//			creatallthings1(address,"#allthings");
//		}
//	});
//	var creatallthings1 = function(address,dom){
//		for(var j = 0;j<address.length;j++){
//			var divallthings1 = $(
//				'<div class="allthings-1">' +
//					'<div class="allthings-image"><a href="#"><img src="' + address[j].imgSrc + '" alt=""></a></div>' +
//        			'<div class="about-logo">' +
//        				'<img src="' + address[j].logoone + '" alt=""><img src="' + address[j].logotwo + '" alt="">' +
//                  '</div>' +
//					'<div class="allthings-name">' +
//	                	'<a href="#" class="allthings_brand_name">' + address[j].brandname + '</a><br>' +
//	                	'<a href="#" class="allthings_product_name">' + address[j].productname + '</a>' +
//					'</div>' +
//					'<div class="allthingsbg"></div>' +
//					'<div class="about-price">' +
//        				'<p class="price2"><b>' + address[j].price + '</b></p>' +
//        				'<p class="save">节省 <b>' + address[j].savetwo + '</b></p>' +
//        			'</div>' +
//				'</div>'	
//			)			
//			$(dom).append(divallthings1);
//		}
//	}
	
	
	//分页
	var pageSize = 12; //每页的数据量
	var totalSize = 0; //总数据量
	var flag = true;
	
	getData(1);
	
	function getData(p){
		
		   $.ajax({
		      	url:"shangpinliebiao.json",
		      	type:"get",
		      	success:function(data){
		      		totalSize = data.datas.length;
		      		//每个页面 2条数据
		      		//数量量  pageSize = 3;
		      		//1.  1 2 3
		      		//2.  4 5 6
		      		//3.  7 8 9
		      		//..
		      		//当前页码     数据量 2个
		      		//start     end
		      		var end = p*pageSize; 
		      		end=end>totalSize?totalSize:end;
		      		var start=p*pageSize - (pageSize-1);
		      		$(".allthings").empty();
		      		for(var i = start;i<=end;i++){
		      			//data[i-1]
		      			var currentObj = data.datas[i-1];
		      			var divallthings1 = $(
								'<div class="allthings-1">' +
									'<div class="allthings-image"><a href="#"><img src="' + currentObj.imgSrc + '" alt=""></a></div>' +
				          			'<div class="about-logo">' +
				          				'<img src="' + currentObj.logoone + '" alt=""><img src="' + currentObj.logotwo + '" alt="">' +
				                    '</div>' +
									'<div class="allthings-name">' +
					                	'<a href="#" class="allthings_brand_name">' + currentObj.brandname + '</a><br>' +
					                	'<a href="#" class="allthings_product_name">' + currentObj.productname + '</a>' +
									'</div>' +
									'<div class="allthingsbg"></div>' +
									'<div class="about-price">' +
				          				'<p class="price2"><b>' + currentObj.price + '</b></p>' +
				          				'<p class="save">节省 <b>' + currentObj.savetwo + '</b></p>' +
				          			'</div>' +
								'</div>');	
							
						$(".allthings").append(divallthings1);
		      		
			      		var pageCount = Math.ceil(totalSize/pageSize);
						if(flag){
							flag = false;
							createPaeBar(pageCount)
						}
					}
		      	},
		      	error:function(){
		      		
		      	}
		      })
	}
	
	function createPaeBar(pageCount){
		//后端会给你返回，总页数，起始页，终止页
		$("#pagination").createPage({
				pageCount:pageCount, //总页数	        
				current:1,  //当前页码
				backFn:function(p){  //回调函数 ，点击当前页的回调函数
					getData(p)
				}
		});
		      		//console.log(data)
	}


})
