$(function(){
//首页
	if($(".changemoney_txtbox option").val='CNY'){
		$(".changemoney i").show();
	}else{
		$(".changemoney i").hide();
	}

	
	
//	//banner轮播图
//	
//	var currentIndex = 0;//当前显示图片项和控制按钮项的索引
//	var termId; //表示轮播定时器线程标识
//		//循环遍历为每一个li注册事件
//		for(var i = 0;i<$('#controls ul li').length;i++){
//			$('#controls ul li').index = i;
//			$('#controls ul li')[i].onmouseenter = function(){
//				currentIndex = this.index;
//				console.log(this==lis[currentIndex]);
//				changeItem();
//			}
//		}	
//		/*轮播*/
//		function autoPlay(){
//			termId = setInterval(function(){
//			currentIndex++;
//			currentIndex%=$('#controls ul li').length;  //控制索引范围
//			changeItem();
//			},3000);
//		}
//		autoPlay();	
//
//		/*改变和当前索引对应li节点和boxItem节点的状态*/
//		function changeItem(){
//			for(var j = 0;j<$('#controls ul li').length;j++){
//					$('#controls ul li')[j].className = "";
//					$('#box-item')[j].className = "box-item";
//					$('#box-item')[j].style.opacity = "0";
////						boxItems[j].style.filter = "alpha(opacity=0)";
//			}
//				//为当前的控制按钮添加背景色
//			$('#controls ul li')[currentIndex].className = "active";
//			$('#box-item')[currentIndex].className = "box-item active";
//			animate($('#box-item')[currentIndex],{opacity:100},100)
//		}
//		
//		$('#banner').onmouseenter = function(){
//			clearInterval(termId)
//		}
//		
//		$('#banner').onmouseleave = function(){
//			autoPlay();
//		}
//		

//	新到货品
	$.ajax({
		type:"get",
		url:"shouye_newabout1.json",
		async:true,
		success:function(data){
			var address = data.datas;
			creatnewabout1(address,"#newabout1");
		}
	});
	var creatnewabout1 = function(address,dom){
		for(var j = 0;j<address.length;j++){
			var divnewabout1 = $(
						'<div class="about1-1">'+
							'<div class="about-image"><a href="' + address[j].linkSrc + '"><img src="' + address[j].imgSrc + '" alt="' + address[j].productname + '"></a></div>' +
                  			'<div class="about-logo">' +
                  				'<img src="' + address[j].logoone + '" alt="new"><img src="' + address[j].logotwo + '" alt="">' +
                            '</div>'        +
 							'<div class="about-name">' +
			                	'<a href="' + address[j].linkSrc + '" class="brand_name"><b>' + address[j].brandnameone + '</b> ' + address[j].brandnametwo + '</a><br>' +
			                	'<a href="' + address[j].linkSrc + '" class="product_name">' + address[j].productname + '</a>' +
							'</div> ' +
							'<div class="aboutbg"></div>' +
							'<div class="about-price">' +
	              				'<p class="price1">' + address[j].priceone + '</p>' +
	              				'<p class="price2"><b>' + address[j].pricetwo + '</b></p>' +
	              				'<p class="save">' + address[j].saveone +  '<b>' + address[j].savetwo + '</b></p>' +
	              			'</div>' +
						'</div>	'		
						)
						
			$(dom).append(divnewabout1);
		}
	}
	
// 最佳用家意见
	$.ajax({
		type:"get",
		url:"shouye_suggest.json",
		async:true,
		success:function(data){
			var address = data.datas;
			creatsuggest(address,"#suggest");
		}
	});
	var creatsuggest = function(address,dom){
		for(var j = 0;j<address.length;j++){
			var dlsuggest = $(
							'<dl>' +
								'<dt><a href="#"><img src="' + address[j].imgSrc + '"/></a></dt>' +
								'<dd>' +
									'<b><a href="#">' + address[j].productname1 + '<br/>' + address[j].productname2 + '</a></b>' +
									'<span>' + address[j].producttime + '</span>' +
									'<p>' + address[j].productmessage + '</p>' +
								'</dd>' +
							'</dl>'	
							)
						
			$(dom).prepend(dlsuggest);
		}
	}
//  编辑分享 顾客帮助
	$.ajax({
		type:"get",
		url:"shouye_share_help.json",
		async:true,
		success:function(data){
			var address1 = data.shares;
			var address2 = data.helps;
			creatshare(address1,"#shares");
			creathelp(address2,"#helps");
		}
	});
	var creatshare = function(address1,dom){
		for(var j = 0;j<address1.length;j++){
			var shareli = $(
							'<li><a href="' + address1[j].sharehref + '">' + address1[j].sharebt + '</a></li>'
							)
						
			$(dom).append(shareli);
		}
	}
	var creathelp = function(address2,dom){
		for(var j = 0;j<address2.length;j++){
			var helpli = $(
							'<li><a href="' + address2[j].sharehref + '">' + address2[j].sharebt + '</a></li>'
							)
			$(dom).append(helpli);
		}
	}






})


