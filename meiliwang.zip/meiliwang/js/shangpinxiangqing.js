$(function(){
	// 收缩展开效果
	$('.things_menutype').click(function(){
		$(this).children('.things_menutype_text').toggle().parents('.things_menutype').siblings('.things_menutype').children('.things_menutype_text').hide();
		
	});
	
	//鼠标滑过加入购物车 图片变换颜色
	$(".things_produce_cart img").mouseover(function(){
    	$('.things_produce_cart img').attr('src','images/add_to_cart_02.gif');
    }).mouseout(function(){
    	$('.things_produce_cart img').attr('src','images/add_to_cart_01.gif');
    })
    //鼠标滑过分享意见 图片变换颜色
	$("#suggest_share").mouseover(function(){
    	$('#suggest_share').attr('src','images/write_a_review_02.gif');
    }).mouseout(function(){
    	$('#suggest_share').attr('src','images/write_a_review_01.gif');
    })
    
    $(".things_img_left").JNMagnifier({ 
		renderTo:".big_things_img" 
	}); 
	
	//购物车
	//点击添加商品到购物车
	$(".things_produce_cart").click(function(){
//		alert(1);
		//从本地中获取	组织的数据
		var productsStr = localStorage["products"];
		if(!productsStr){ //表示目前本地当中还没有创建 数据的容器
			localStorage["products"] = '[]';
		}
		//在添加数据之前必须保证本地有能管理数据的 容器
		//如果容器当中有存在过的该种类的产品，所要做的是改变该产品的数量。  否则，创建该种类对象存放在容器当中。
		//再获取一次，因为productsStr第一次获取的时候，可能是undefined
		productsStr = localStorage["products"]; //获取字符串的json
		var productsObj = JSON.parse(productsStr);
		//[{},{},{}]  //数组对象
		var div=$(this).parent(); //div jquery对象
		var pid=div.attr("pid");//产品的编号
		//alert(pid)
		//循环遍历容器中的数据，判断是否已经存在该商品，若存在，改变商品的数量。否则，添加一条相关该产品的数据（对象{}）
		for(var i = 0;i<productsObj.length;i++){
			//表示当前的正则遍历的产品对象
			var currentObj = productsObj[i];
			if(currentObj.pid==pid){//已经存在该商品
				//改变该商品的数量
				productsObj[i].pCount = parseInt(productsObj[i].pCount) + 1;
				//把改变后的数组的对象转换成 字符串Json存在在本地当中
				localStorage["products"] = JSON.stringify(productsObj);
				return;
			}
		}
		//商品图片
		var pImgSrc = $(".things_produce_img").eq(0).find("img").eq(0).attr("src");
		//console.log(pImgSrc)
		//活动小图标
		var pIconSrc = $(".things_produce_icon").eq(0).find("img").eq(0).attr("src");
//		console.log(pIconSrc)
		//货品名称
		var pName = $(".things_mingcheng").eq(0).find("i").eq(0).text();
//		console.log(pName)
		//容量
		var pRongliang=$(".things_rongliang").text();
//		console.log(pRongliang)
		//货号
		var pHuohao=$(".things_mingcheng").eq(0).find("i").eq(1).text();
//		console.log(pHuohao)
		//单价
		var prcie1 = $(".things_produce_price").find("b").eq(0).find("i").text();
		var prcie2 = $(".things_produce_price1").find("s").text();
		var prcie3 = $(".things_produce_price3").text();
//		console.log(prcie3)
		//数量
		var pNumber = $(".things_produce_number_box").val();
//		console.log(pNumber)
		//组织好改产品数据
		var pObj = {pid:pid,pImgSrc:pImgSrc,pIconSrc:pIconSrc,pName:pName,pRongliang:pRongliang,pHuohao:pHuohao,prcie1:prcie1,prcie2:prcie2,prcie3:prcie3,pNumber:pNumber,pCount:1};
//		console.log(pObj)
		productsObj.push(pObj);
		//把改变后的数组的对象转换成 字符串Json存在在本地当中
		localStorage["products"] = JSON.stringify(productsObj);

		
	})

	
	
	
	
})