window.onload=function(){
	function LunBoOpa(id,dataurl){
		this.bigBox = document.getElementById(id);
		this.box = this.bigBox.querySelector(".inner-box");
		this._ul = this.bigBox.querySelector(".controls ul");
		this.dataUrl = dataurl;
		this.currentIndex = 0;
		this.lis = null;
		this.termId;
		this.run();
	}
	LunBoOpa.prototype = {
		run:function(){
			this.getData();
			this.autoPlay();
			//this.mouseControl();
		},
		getData:function(){
			var that = this;
			ajax({
				method:"get",
				url:this.dataUrl,
				success:function(data){
					var obj = JSON.parse(data);
					var arr = obj.datas;
					that.creatDivAndLi(arr);
				},
				error:function(mes){
					
				}
			});
		},
		//动态创造div和li
		creatDivAndLi:function(arr){
			var that = this;
			for(var i = 0;i<arr.length;i++){
				if(i==0){
					var firstDiv = document.createElement("div");
					var firstLi = document.createElement("li");
					firstDiv.className = "box-item active default";
					firstLi.className = "active";
					firstDiv.innerHTML = 
						'<a href="' +arr[0].target + '">' +
							'<img src="' +arr[0].imgSrc + '" alt="" />' +
						'</a>';
					this.box.appendChild(firstDiv);
					this._ul.appendChild(firstLi);
				}else{
					var _div = document.createElement("div");
					var _li = document.createElement("li");
					_div.className = "box-item";
					_div.innerHTML =
						'<a href="' +arr[i].target + '">' +
							'<img src="' +arr[i].imgSrc + '" alt="" />' +
						'</a>'
					this.box.appendChild(_div);
					this._ul.appendChild(_li);
				}
			}
			this.boxItems = this.box.querySelectorAll(".box-item");
			this.lis = this._ul.getElementsByTagName("li");
			//每个li的鼠标滑过事件
			for(var k = 0;k<this.lis.length;k++){
				this.lis[k].index = k;
				this.lis[k].onclick= function(){
					that.currentIndex = this.index;
					//console.log(this==that.lis[that.currentIndex]);
					that.changeItem();					
				}
			}
			//console.log(this._ul);
			//console.log(this.boxItems.length);
			//console.log(this.lis.length);
		},
		/*轮播*/
		autoPlay:function(){
			var that = this;
			this.termId = setInterval(function(){
			that.currentIndex++;
			that.currentIndex%=that.lis.length;  //控制索引范围
			that.changeItem();								
			},5000);
		},		
		/*改变和当前索引对应li节点和boxItem节点的状态*/
		changeItem:function(){
			for(var j = 0;j<this.lis.length;j++){
					this.lis[j].className = "";
					this.boxItems[j].className = "box-item";
					this.boxItems[j].style.opacity = ".3";
					this.boxItems[j].style.filter = "alpha(opacity=30)";
			}
				//为当前的控制按钮添加背景色
			this.lis[this.currentIndex].className = "active";
			this.boxItems[this.currentIndex].className = "box-item active";
			animate(this.boxItems[this.currentIndex],{opacity:100},300)
		},
//		mouseControl:function(){
//			var that = this;
//			this.bigBox.onmouseenter = function(){
//				clearInterval(that.termId)
//			}
//			
//			this.bigBox.onmouseleave = function(){
//				that.autoPlay();
//			}
//		},

	}
var lunbo1 = new LunBoOpa("banner","shouye_lunbotu.json");
}
