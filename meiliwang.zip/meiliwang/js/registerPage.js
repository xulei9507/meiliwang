/*
 思路；
 第一步：当页面加载完后获取所要操作的节点对象（所有的input）
 		通过定义一个函数$j来获取他们
 第二步：为每一个input节点对象注册相关表单事件（onfocus onblur onkeyup）
第三步：执行逻辑
 */

/*定义一个获取函数*/
function $j(id){
	return document.getElementById(id);
}

var regs={
	name_txtReg:/^(([\u4e00-\u9fa5])|([a-zA-Z0-9_-])+$)/,		//支持汉字[\u4e00-\u9fa5]/g、字母、数字、“-”、“_”,4-20个字符
	numReg:/\d/,	//数字
	strReg:/\w/,	//字母
	tsReg:/^(([\u4e00-\u9fa5])|([a-zA-Z0-9]))$/,	//取反是特殊字符  特殊标识
	email_txt1Reg:/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/		//邮箱
}

/*页面加载*/
window.onload=function(){
	/*获取所要操作的节点对象（所有的input）*/
	/*称谓*/
	var nametitle_box=$j("nametitle_box");
	/*用户名*/
	var name_txt=$j("name_txt");
	/*所在地*/
	var country_box=$j("country_box");
	/*邮箱*/
	var email_txt1=$j("email_txt1");
	/*确认邮箱*/
	var email_txt2=$j("email_txt2");
	/*建立密码*/
	var password_txt1=$j("password_txt1");
	/*再次输入密码*/
	var password_txt2=$j("password_txt2");
	
	/*使用条款*/
	var zhuce_choose=$j("zhuce_choose");
	/*图像核证*/
	var yanzheng_txt=$j("yanzheng_txt");
	/*注册按钮*/
	var submit=$j("submit");
	/*错误提示*/
	var tipbox=$j("zhuce_errMess")
	/*为每一个input节点对象注册相关表单事件（onfocus onblur onkeyup）*/
	
	/*-------------称谓-------------*/
	nametitle_box.onblur=function(e){
		//alert(1);
		var _event=window.event||e;//获取事件对象
		checknametitle_box(_event);	//调用checknametitle_box函数		
		
	}
	//定义一个checknametitle_box的函数
	function checknametitle_box(_e){
		var type;	//事件类型
		if(_e){
			type=_e.type;	//判断发生事件的类型：onblur onfocus onkeyup
		}	
		var v=nametitle_box.value;	//文本框属性值
		var err=$j("errMess1s");//*
		
		var tip=$j("errMess1");//错误提示
		if(v=="--"){
			//alert(v.length)
			//if(v.length==2){	//onclick事件    点时触发
			err.style.visibility="visible";
			tipbox.style.display="block";
			tip.style.display="block";
			return false;
		}else{
			err.style.visibility="hidden";
			//tipbox.style.display="none";
			tip.style.display="none";
			return true;
		}
	}	
//	/*-------------用户名检测------------*/
//	/*onblur元素失去焦点时触发。
//	  onfocus元素获得焦点时触发。
//	  onkeyup输入字符时触发*/
	name_txt.onblur=function(e){
		var _event=window.event||e;//获取事件对象
		checkname_txt(_event);	//调用checkname_txt函数
	}
	//定义一个checkname_txt的函数
	function checkname_txt(_e){
		var type;	//事件类型
		if(_e){
			type=_e.type;	//判断发生事件的类型：onblur onfocus onkeyup
		}
		var v=name_txt.value;	//文本框属性值
		var err=$j("errMess1s");//*
		
		var tip=$j("errMess1");//错误提示
		if(v.length==0){
			//alert(v.length)
			//if(v.length==2){	//onclick事件    点时触发
			err.style.visibility="visible";
			tipbox.style.display="block";
			tip.style.display="block";
			return false;
		}else{
			err.style.visibility="hidden";
			//tipbox.style.display="none";
			tip.style.display="none";
			return true;
		}
	}
	/*-------------所在地-------------*/
	country_box.onblur=function(e){
		var _event=window.event||e;//获取事件对象
		checkcountry_box(_event);	//调用checkcountry_box函数
	}
	//定义一个checkcountry_box的函数
	function checkcountry_box(_e){
		var type;	//事件类型
		if(_e){
			type=_e.type;	//判断发生事件的类型：onblur onfocus onkeyup
		}
		var v=country_box.value;	//文本框属性值
		var err=$j("errMess2s");//*
		
		var tip=$j("errMess2");//错误提示
		if(v=="--"){
			//alert(v.length)
			//if(v.length==2){	//onclick事件    点时触发
			err.style.visibility="visible";
			tipbox.style.display="block";
			tip.style.display="block";
			return false;
		}else{
			err.style.visibility="hidden";
			//tipbox.style.display="none";
			tip.style.display="none";
			return true;
		}
	}
	/*-------------邮箱检测------------*/
	email_txt1.onblur=function(e){
		var _event=window.event||e;//获取事件对象
		checkemail_txt1(_event);	//调用checkname_txt函数
	}
	//定义一个checkemail_txt1的函数
	function checkemail_txt1(_e){
		var type;	//事件类型
		if(_e){
			type=_e.type;	//判断发生事件的类型：onblur onfocus onkeyup
		}
		var v=email_txt1.value;	//文本框属性值
		var err=$j("errMess3s");//*
		
		var tip=$j("errMess3");//错误提示
		if(v.length==0){  //	为空时
			//alert(v.length)
			//if(v.length==2){	//onclick事件    点时触发
			err.style.visibility="visible";
			tipbox.style.display="block";
			tip.style.display="block";
			return false;
		}else{//不为空时
			if(!regs.email_txt1Reg.test(v)){
				err.style.visibility="visible";
				tipbox.style.display="block";
				tip.style.display="block";
				return false;
			}else{
				err.style.visibility="hidden";
				//tipbox.style.display="none";
				tip.style.display="none";
				return true;
			}
		}
	}
	
	/*-------------确认邮箱检测------------*/
	email_txt2.onblur=function(e){
		var _event=window.event||e;//获取事件对象
		checkemail_txt2(_event);	//调用checkname_txt函数
	}
	//定义一个checkemail_txt1的函数
	function checkemail_txt2(_e){
		var type;	//事件类型
		if(_e){
			type=_e.type;	//判断发生事件的类型：onblur onfocus onkeyup
		}
		var v=email_txt2.value;	//文本框属性值
		var v1=email_txt1.value;
		var err=$j("errMess4s");//*
		
		var tip=$j("errMess4");//错误提示
		if(v.length==0){  //	为空时
			//alert(v.length)
			//if(v.length==2){	//onclick事件    点时触发
			err.style.visibility="visible";
			tipbox.style.display="block";
			tip.style.display="block";
			return false;
		}else{//不为空时
			if(v!=v1){
				err.style.visibility="visible";
				tipbox.style.display="block";
				tip.style.display="block";
				return false;
			}else{
				err.style.visibility="hidden";
				//tipbox.style.display="none";
				tip.style.display="none";
				return true;
			}
		}
	}	

	/*-------------密码检测------------*/
	password_txt1.onblur=function(e){
		var _event=window.event||e;//获取事件对象
		checkpassword_txt1(_event);	//调用checkname_txt函数
	}
	//定义一个checkpassword_txt1的函数
	function checkpassword_txt1(_e){
		var type;	//事件类型
		if(_e){
			type=_e.type;	//判断发生事件的类型：onblur onfocus onkeyup
		}
		var v=password_txt1.value;	//文本框属性值
		var err=$j("errMess5s");//*
		
		var tip=$j("errMess5");//错误提示
		if(v.length==0){  //	为空时
			//alert(v.length)
			//if(v.length==2){	//onclick事件    点时触发
			err.style.visibility="visible";
			tipbox.style.display="block";
			tip.style.display="block";
			return false;
		}else{//不为空时
			if(v.length>=6&&v.length<=12){
				if(!(regs.numReg.test(v)&&regs.strReg.test(v))){
					err.style.visibility="visible";
					tipbox.style.display="block";
					tip.style.display="block";
					return false;
				}else{
					err.style.visibility="hidden";
					//tipbox.style.display="none";
					tip.style.display="none";
					return true;
				}
			}else{
				err.style.visibility="visible";
				tipbox.style.display="block";
				tip.style.display="block";
				return false;
			}
		}
	}
	/*-------------再次输入密码------------*/
	password_txt2.onblur=function(e){
		var _event=window.event||e;//获取事件对象
		checkpassword_txt2(_event);	//调用checkname_txt函数
	}
	//定义一个checkpassword_txt2的函数
	function checkpassword_txt2(_e){
		var type;	//事件类型
		if(_e){
			type=_e.type;	//判断发生事件的类型：onblur onfocus onkeyup
		}
		var v=password_txt2.value;	//文本框属性值
		var v1=password_txt1.value;
		var err=$j("errMess6s");//*
		
		var tip=$j("errMess6");//错误提示
		if(v.length==0){  //	为空时
			//alert(v.length)
			//if(v.length==2){	//onclick事件    点时触发
			err.style.visibility="visible";
			tipbox.style.display="block";
			tip.style.display="block";
			return false;
		}else{//不为空时
			if(v!=v1){
				err.style.visibility="visible";
				tipbox.style.display="block";
				tip.style.display="block";
				return false;
			}else{
				err.style.visibility="hidden";
				//tipbox.style.display="none";
				tip.style.display="none";
				return true;
			}
		}
	}		
	/*-------------使用条款------------*/
	zhuce_choose.onblur=function(e){
		var _event=window.event||e;//获取事件对象
		checkzhuce_choose(_event);	//调用checkname_txt函数
	}
	//定义一个checkzhuce_choose的函数
	function checkzhuce_choose(_e){
		var type;	//事件类型
		if(_e){
			type=_e.type;	//判断发生事件的类型：onblur onfocus onkeyup
		}
		var err=$j("errMess7s");//*
		var tip=$j("errMess7");//错误提示
		if(zhuce_choose.checked){
			err.style.visibility="hidden";
				//tipbox.style.display="none";
				tip.style.display="none";
				return true;
		}else{
			err.style.visibility="visible";
			tipbox.style.display="block";
			tip.style.display="block";
			return false;
		}
	}	
	
	/*-------------图像核证-------------*/
	yanzheng_txt.onblur=function(e){
		var _event=window.event||e;//获取事件对象
		checkyanzheng_txt(_event);	//调用checkname_txt函数
	}
	//定义一个checkyanzheng_txt的函数
	function checkyanzheng_txt(_e){
		var type;	//事件类型
		if(_e){
			type=_e.type;	//判断发生事件的类型：onblur onfocus onkeyup
		}
		var v=yanzheng_txt.value;	//文本框属性值
		var err=$j("errMess8s");//*
		var tip=$j("errMess8");//错误提示
		//alert(v.length)
		if(v.length==10){
			//alert(v)
			//alert(v.length)
			err.style.visibility="visible";
			tipbox.style.display="block";
			tip.style.display="block";
			return false;
		}else{
			if(v=="HEAS"||v=="WVLR"){
				err.style.visibility="hidden";
				//tipbox.style.display="none";
				tip.style.display="none";
				return true;
			}else{
				err.style.visibility="visible";
				tipbox.style.display="block";
				tip.style.display="block";
				return false;
			}
			
		}
	}
	
	/*-------------注册按钮检测------------*/
	submit.onclick=function(){
		if(
			checknametitle_box()&&
			checkname_txt()&&
			checkcountry_box()&&
			checkemail_txt1()&&
			checkemail_txt2()&&
			checkpassword_txt1()&&
			checkpassword_txt2()&&
			checkzhuce_choose()&&
			checkyanzheng_txt()
		){
			tipbox.style.display="none";//提示信息隐藏
			alert("注册成功，进入登录页面")
			//注册成功后将信息存储在本地
			localStorage["name"] = name_txt.value;
			localStorage["email"] = email_txt1.value;
			localStorage["pwd"] = password_txt1.value;
			localStorage["isLogin"] = "false";
			window.location.href = "dengluzhuce.html";
		}else{
			tipbox.style.display="block";
		}
	}
	
}





















